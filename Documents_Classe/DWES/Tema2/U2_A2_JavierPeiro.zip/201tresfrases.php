<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica1</title>
</head>
<body>
    <?php
        /*
        Activitat 2_01. 201tresfrases.php: Mostra 3 frases, cadascuna en un paràgraf utilitzant
        les tres possibilitats que hi ha de mostrar contingut. Després, introdueix dos comentaris, un
        de bloc i un altre d'una línia.
        */
        echo "<p>Esta es la frase 1</p>";
        #Comentari de una sola linea
        print ("<p>Esta es la frase 2</p>");
        //Un altre comentari de una sola linea
        ?>
        <p><?= "Esta es la frase 3" ?></p>
</body>
</html>