<?php

$persones=[
    ["paco"=> "paco", ["edat"=>25, "professio"=> "panader"]]
];
?>