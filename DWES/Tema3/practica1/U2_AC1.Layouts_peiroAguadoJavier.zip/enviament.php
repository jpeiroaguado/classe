<?php
require __DIR__.'/header.php' ;
require __DIR__.'/footer.php' ;
?>
<div class="contenedor">
    <h1>Thanks!</h1>
<img src="caja.png">
</div>
