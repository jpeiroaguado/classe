<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .capçalera{
            width: 100%;
            height: 150px;
            background-color: black;
            color:gold;
            font-size:80px;
            top: 0;
            display:flex;
            justify-content:center;
            align-items: center;
            
        }
        .footer{
            width: 100%;
            height: 150px;
            background-color: black;
            color:gold;
            font-size:30px;
            position: absolute;
            bottom: 0;
            display:flex;
            align-items: center; 
            justify-content: center;
            align-items: center;
        }       
        .contenedor{
            width: 100%;
            height: 60%;
            display: flex;
            flex-direction: column; 
            align-items: center; 
            justify-content: center;
        }
        .contenedorForm {
            display: flex;
            justify-content: space-between;
            justify-content:center;
        }
        .boton{
            background-color:red;
            width:90px;
            height:45px;
            
        }
        .boton2{
            background-color:red;
            width:90px;
            height:45px;
            
        }
        .textos{
            width:500px;
            height:60px;
            margin:20px;
        }
        .imgCart{
            width:100px;
            height:100px;
        }
        img{
            width:700px;
            height:700px;
        }
    </style>
</head>
<body>
<header class="capçalera">
    STAR WARS SHOP
</header>
