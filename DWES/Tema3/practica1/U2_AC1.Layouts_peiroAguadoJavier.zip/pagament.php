<?php
require __DIR__.'/header.php' ;
require __DIR__.'/footer.php' ;
?>
<div class="contenedor">
<h1>Shipping form</h1>
    <div class="contenedorForm">
        <form action="enviament.php">
            <input type="text" class="textos"><br>
            <input type="text" class="textos"><br>
            <input type="text" class="textos"><br>
            <input type="submit" value="BUY" class="boton2">
        </form>
        <img src="./cartera.png" class="imgCart">
    </div>
</div>
