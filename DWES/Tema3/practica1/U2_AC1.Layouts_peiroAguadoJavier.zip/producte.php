<?php
require __DIR__.'/header.php' ;
require __DIR__.'/footer.php' ;
?>
<div class="contenedor">
<img src="casco.png">
<button value="buy" class="boton">BUY</button>
</div>
