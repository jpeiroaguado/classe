<footer class="footer">Terms of use | contact</footer>
</body>
</html>