<!--
215suma110.php: Escriu un programa que sume els números de l'1 al 10.-->
<ul>
<?php
        $num=1;
        for($x=1;$x<=10;$x++){
                $num+=$x+1;
                echo "<li>".$num."</li>";
            }

?>
</ul>